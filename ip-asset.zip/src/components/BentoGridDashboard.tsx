/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Cpu, 
  DollarSign, 
  Users, 
  FileText, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  Code2, 
  Layers,
  TrendingUp,
  Activity
} from 'lucide-react';
import { LicensingProfile } from '../types';
import { TabType } from './Header';

interface BentoGridDashboardProps {
  profile: LicensingProfile;
  onNavigateTab: (tab: TabType) => void;
  onOpenAiAudit: () => void;
}

export const BentoGridDashboard: React.FC<BentoGridDashboardProps> = ({
  profile,
  onNavigateTab,
  onOpenAiAudit
}) => {
  const { asset, valuation, licensingTiers, buyerMatches } = profile;

  // Real pipeline calculations derived from the analyzed asset
  const pipelineValueUsd = buyerMatches.reduce((sum, b) => sum + (b.suggestedDealSizeUsd || 0), 0);
  const avgFitScore = buyerMatches.length > 0
    ? (buyerMatches.reduce((sum, b) => sum + b.fitScore, 0) / buyerMatches.length).toFixed(1)
    : '94.0';

  return (
    <div className="space-y-4">
      {/* Top Banner: Real Analyzed Asset Status */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-4 md:p-5 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Assessed Technical Asset
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                {asset.size_metrics.loc.toLocaleString()} LOC • {asset.size_metrics.file_count} Files • {asset.languages.join(', ')}
              </span>
            </div>
            <h2 className="text-base font-bold text-white font-mono uppercase tracking-tight mt-0.5">
              {asset.name}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            id="bento-run-audit-btn"
            onClick={onOpenAiAudit}
            className="flex items-center gap-1.5 bg-blue-600/15 hover:bg-blue-600/25 text-blue-400 border border-blue-500/30 px-3.5 py-2 rounded-xl text-xs font-bold font-mono transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI IP Commercial Audit</span>
          </button>
          <button
            id="bento-view-contracts-btn"
            onClick={() => onNavigateTab('contracts')}
            className="flex items-center gap-1.5 bg-[#111111] hover:bg-[#161616] text-neutral-200 border border-[#1a1a1a] px-3.5 py-2 rounded-xl text-xs font-bold font-mono transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>View MLA Drafts</span>
          </button>
        </div>
      </div>

      {/* Main 12-Column High-Density Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* ------------------------------------------------------------- */}
        {/* TILE 1: ASSET INTELLIGENCE & INVARIANTS (Span 8 cols)         */}
        {/* ------------------------------------------------------------- */}
        <div className="col-span-1 md:col-span-12 lg:col-span-8 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 shadow-2xl flex flex-col justify-between hover:border-[#2a2a2a] transition">
          <div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] font-bold text-blue-400 tracking-widest uppercase font-mono">
                  Layer 1 // AST Extraction
                </span>
                <h3 className="text-sm font-bold text-white font-mono uppercase mt-0.5">
                  Extracted Architectural Profile
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-neutral-400 bg-[#050505] px-2.5 py-1 rounded-lg border border-[#1a1a1a]">
                  Complexity Index: <strong className="text-white">{asset.size_metrics.cyclomatic_index.toFixed(1)}/10</strong>
                </span>
              </div>
            </div>

            {/* Dynamic Claims derived from code */}
            <div className="space-y-2 mb-4">
              {asset.claims.map((claim, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-neutral-300 font-mono bg-[#050505] p-2.5 rounded-xl border border-[#1a1a1a]">
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{claim}</span>
                </div>
              ))}
            </div>

            {/* Capabilities Pill Matrix */}
            <div className="flex flex-wrap gap-1.5 mb-2">
              {asset.features.capabilities.map((cap, idx) => (
                <span 
                  key={idx} 
                  className="px-2.5 py-1 bg-[#111111] text-neutral-300 text-[11px] font-mono rounded-lg border border-[#1a1a1a]"
                >
                  {cap}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
              <span>{asset.size_metrics.file_count} Files Parsed</span>
              <span>•</span>
              <span>{asset.size_metrics.loc.toLocaleString()} Verified Lines</span>
              <span>•</span>
              <span className="text-green-400">Cleanroom Lineage</span>
            </div>
            <button
              id="bento-inspect-ast-btn"
              onClick={() => onNavigateTab('intake')}
              className="text-xs text-blue-400 hover:text-blue-300 font-mono font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Inspect Raw AST</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* TILE 2: ENTERPRISE BUYER MATCHING (Span 4 cols)               */}
        {/* ------------------------------------------------------------- */}
        <div className="col-span-1 md:col-span-12 lg:col-span-4 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 shadow-2xl flex flex-col justify-between hover:border-[#2a2a2a] transition">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-widest font-mono">
                Matched Enterprise Targets
              </h3>
              <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                {buyerMatches.length} Profile{buyerMatches.length > 1 ? 's' : ''}
              </span>
            </div>

            <div className="space-y-2.5">
              {buyerMatches.slice(0, 3).map((match) => (
                <div 
                  key={match.id}
                  onClick={() => onNavigateTab('buyers')}
                  className="p-3 bg-[#050505] hover:bg-[#111111] rounded-xl border border-[#1a1a1a] flex justify-between items-center transition cursor-pointer"
                >
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-bold text-white truncate">{match.companyName}</p>
                    <p className="text-[10px] text-neutral-500 truncate">{match.sector}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-bold text-blue-400 font-mono">{match.fitScore.toFixed(1)}%</p>
                    <p className="text-[9px] text-neutral-600 font-mono">Fit Score</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a]">
            <div className="flex justify-between text-[10px] text-neutral-400 mb-2 font-mono">
              <span>Avg. Counterparty Fit</span>
              <span className="text-blue-400 font-bold">{avgFitScore}%</span>
            </div>
            <button
              id="bento-open-campaigns-btn"
              onClick={() => onNavigateTab('buyers')}
              className="w-full py-2 bg-[#111111] hover:bg-neutral-800 text-neutral-200 text-xs font-bold font-mono rounded-xl border border-[#1a1a1a] transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Review Buyer Outreach ({buyerMatches.length})</span>
              <ArrowRight className="w-3 h-3 text-blue-400" />
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* TILE 3: VALUATION & TIERS (Span 5 cols)                       */}
        {/* ------------------------------------------------------------- */}
        <div className="col-span-1 md:col-span-6 lg:col-span-5 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 flex flex-col justify-between shadow-2xl hover:border-[#2a2a2a] transition">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-widest font-mono">
                Valuation & Licensing Yield
              </h3>
              <span className="text-[10px] font-mono text-neutral-400 bg-[#050505] px-2 py-0.5 rounded border border-[#1a1a1a]">
                Score: <strong className="text-white">{valuation.valueScore}/10</strong>
              </span>
            </div>

            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-3xl font-light text-white font-mono tracking-tight">
                ${(valuation.estimatedAnnualValueUsd / 1000).toFixed(0)}K
              </span>
              <span className="text-xs text-neutral-500 uppercase font-mono tracking-tighter">
                Est. Annual Yield (TAM: ${(valuation.estimatedTamUsd / 1000000).toFixed(1)}M)
              </span>
            </div>

            <div className="space-y-2.5">
              {licensingTiers.slice(0, 2).map((tier, idx) => (
                <div 
                  key={tier.id}
                  className={`flex justify-between items-center p-3 bg-[#050505] rounded-xl border-l-2 ${
                    idx === 0 ? 'border-blue-500' : 'border-neutral-700'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <p className="text-[11px] font-bold text-white uppercase font-mono truncate">{tier.name}</p>
                    <p className="text-[10px] text-neutral-400 truncate">{tier.rateDescription}</p>
                  </div>
                  <span className="text-[10px] font-bold text-neutral-400 font-mono flex-shrink-0">
                    {idx === 0 ? 'DEFAULT' : 'OEM'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex items-center justify-between">
            <span className="text-[10px] text-neutral-500 font-mono">{licensingTiers.length} Configured Tiers</span>
            <button
              id="bento-explore-valuation-btn"
              onClick={() => onNavigateTab('valuation')}
              className="text-xs text-blue-400 hover:text-blue-300 font-mono font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Explore Modeler</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* TILE 4: COMMERCIAL DEAL FLOW PIPELINE (Span 3 cols)           */}
        {/* ------------------------------------------------------------- */}
        <div className="col-span-1 md:col-span-6 lg:col-span-3 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 flex flex-col justify-between shadow-2xl hover:border-[#2a2a2a] transition">
          <div>
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-widest mb-3 font-mono">
              Potential Deal Pipeline
            </h3>

            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-neutral-500">TARGET BUYERS</span>
                <span className="text-lg font-bold text-white">{buyerMatches.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-neutral-500">PIPELINE VALUE</span>
                <span className="text-lg font-bold text-blue-400">
                  ${Math.round(pipelineValueUsd / 1000)}K
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-neutral-500">DEFENSIBILITY</span>
                <span className="text-lg font-bold text-green-400">
                  {profile.asset.defensibility[0]?.score || 92}/100
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a]">
            <div className="bg-[#050505] p-2 rounded-lg border border-[#1a1a1a] text-[10px] font-mono text-neutral-400 text-center">
              Based on {asset.size_metrics.loc} parsed lines
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* TILE 5: GOVERNANCE & SAFETY (Span 4 cols)                     */}
        {/* ------------------------------------------------------------- */}
        <div className="col-span-1 md:col-span-12 lg:col-span-4 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 flex flex-col justify-between shadow-2xl hover:border-[#2a2a2a] transition">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest font-mono">
                Governance & IP Safety
              </h3>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-[10px] text-green-400 font-mono font-bold">VERIFIED</span>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono text-neutral-300">
              <div className="bg-[#050505] p-2.5 rounded-xl border border-[#1a1a1a] flex items-center justify-between">
                <span>DTSA Trade Secrets</span>
                <span className="text-green-400 font-bold">Compliant</span>
              </div>
              <div className="bg-[#050505] p-2.5 rounded-xl border border-[#1a1a1a] flex items-center justify-between">
                <span>GPL / Copyleft Contagion</span>
                <span className="text-green-400 font-bold">0 Detected</span>
              </div>
              <div className="bg-[#050505] p-2.5 rounded-xl border border-[#1a1a1a] flex items-center justify-between">
                <span>Cleanroom Provenance</span>
                <span className="text-blue-400 font-bold">100% Intact</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex items-center justify-between">
            <span className="text-[10px] text-neutral-500 font-mono">Governed under Delaware Law</span>
            <button
              id="bento-inspect-governance-btn"
              onClick={() => onNavigateTab('contracts')}
              className="text-xs text-blue-400 hover:text-blue-300 font-mono font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>View Indemnity Terms</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
