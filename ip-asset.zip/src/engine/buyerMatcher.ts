/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AssetObject, BuyerMatch, ValuationBreakdown } from '../types';

export class BuyerMatcher {
  public static discoverBuyers(asset: AssetObject, valuation: ValuationBreakdown): BuyerMatch[] {
    const annualEst = valuation.estimatedAnnualValueUsd;
    const kind = asset.primarykind;
    const langList = asset.languages.join(', ');
    const caps = asset.features.capabilities;
    const topCap = caps[0] || "High-Performance Modular Architecture";
    const secondCap = caps[1] || "Cleanroom Software Infrastructure";
    const primaryClaim = asset.claims[0] || `Production-grade ${langList} implementation with ${asset.size_metrics.loc} lines`;

    // Dynamic buyer sets tailored to the detected primary kind
    if (kind === 'aimodel') {
      return [
        {
          id: "buyer-ai-hyperscaler",
          companyName: "NexusScale Cloud Systems",
          sector: "AI Inference Infrastructure & GPU Cloud",
          fitScore: 98.2,
          primaryPainPoint: "High GPU memory bandwidth saturation and soaring multi-tenant cluster compute electricity costs.",
          matchedCapabilities: caps.slice(0, 3),
          annualSavingsEstimateUsd: Math.round(annualEst * 1.8),
          recommendedTier: "Enterprise Compute & Value-Share (4.5% of savings)",
          contactPersona: "VP of AI Infrastructure & Cluster Efficiency",
          suggestedDealSizeUsd: Math.round(annualEst * 0.12),
          pitchAngle: `Accelerate model inference throughput and compress cluster electricity overhead using ${asset.name}.`,
          outreachSequence: {
            emailSubject: `Accelerating NexusScale GPU cluster efficiency with ${asset.name}`,
            emailBody: `Hi [First Name],

I noticed NexusScale has been aggressively scaling GPU infrastructure for high-throughput model inference workloads.

We have engineered an enterprise software asset (${asset.name}) in ${langList} featuring ${topCap}.

Key verified outcome:
• ${primaryClaim}
• Cleanroom DTSA-protected architecture with zero GPL copyleft contagion
• Rapid drop-in deployment with zero upstream pipeline refactoring

Would you be open to reviewing a 1-page technical architecture brief and running a 15-minute benchmark in your sandbox?

Best regards,
Commercialization Team`,
            technicalBrief: `Deploys optimized tensor kernel execution routines in ${langList}. Validated across ${asset.size_metrics.file_count} modules with formal invariant verification.`
          }
        },
        {
          id: "buyer-enterprise-genai",
          companyName: "CognitivePulse Analytics",
          sector: "Enterprise LLM & Predictive Analytics",
          fitScore: 93.6,
          primaryPainPoint: "Inference latency bottlenecks during multi-modal embedding generation and live scoring.",
          matchedCapabilities: [topCap, secondCap],
          annualSavingsEstimateUsd: Math.round(annualEst * 1.1),
          recommendedTier: "Dedicated Node Infrastructure License",
          contactPersona: "Chief Technology Officer & Head of Machine Learning",
          suggestedDealSizeUsd: Math.round(annualEst * 0.08),
          pitchAngle: `Eliminate latency spikes in high-volume inference workflows.`,
          outreachSequence: {
            emailSubject: `Sub-millisecond inference acceleration for CognitivePulse`,
            emailBody: `Hi [First Name],

Reaching out because our team has developed ${asset.name}, designed to streamline enterprise machine learning workloads.

Featuring ${topCap}, this module achieves ${primaryClaim}.

We are offering enterprise node licensing with white-glove technical integration support.

Let me know if you would like to test our sanitized benchmarks.

Best regards,
Commercialization Team`,
            technicalBrief: `Integrates streamlined data pipelines with zero-copy buffer handoffs to maximize pipeline throughput under peak batch queries.`
          }
        },
        {
          id: "buyer-autonomous-robotics",
          companyName: "Vanguard Autonomous Robotics",
          sector: "Robotics & Edge Sensor Systems",
          fitScore: 90.1,
          primaryPainPoint: "Edge compute power consumption constraints on embedded battery-powered mobile units.",
          matchedCapabilities: caps.slice(0, 2),
          annualSavingsEstimateUsd: Math.round(annualEst * 0.85),
          recommendedTier: "OEM Embedded Hardware & Firmware Royalty",
          contactPersona: "Head of Embedded Systems Architecture",
          suggestedDealSizeUsd: Math.round(annualEst * 0.06),
          pitchAngle: `Deploy low-footprint tensor routines directly onto edge hardware boards.`,
          outreachSequence: {
            emailSubject: `Edge execution runtime for Vanguard Autonomous systems`,
            emailBody: `Hi [First Name],

When deploying complex algorithms onto mobile robotics, compute power budget is a persistent constraint.

Our team packaged ${asset.name} with dedicated cross-compilation support to achieve ${primaryClaim}.

Let me know if we can share our embedded evaluation suite.

Best regards,
Commercialization Team`,
            technicalBrief: `Features low-overhead execution loop with deterministic memory boundaries.`
          }
        }
      ];
    }

    if (kind === 'distributed_system' || kind === 'codelibrary') {
      return [
        {
          id: "buyer-cloud-stream",
          companyName: "Chronos Distributed Systems",
          sector: "Cloud Native Stream Processing & Telemetry",
          fitScore: 97.4,
          primaryPainPoint: "Write-ahead log serialization and network socket overhead under multi-tenant cloud ingestion.",
          matchedCapabilities: caps.slice(0, 3),
          annualSavingsEstimateUsd: Math.round(annualEst * 1.5),
          recommendedTier: "Enterprise Compute & Value-Share (4.5% of savings)",
          contactPersona: "VP of Cloud Engineering & Core Infrastructure",
          suggestedDealSizeUsd: Math.round(annualEst * 0.1),
          pitchAngle: `Scale ingestion pipeline throughput with zero-contention modular architecture.`,
          outreachSequence: {
            emailSubject: `Streamlining Chronos streaming ingestion with ${asset.name}`,
            emailBody: `Hi [First Name],

Reaching out because our team has architected ${asset.name} (${langList}), providing ${topCap}.

Key verified outcome:
• ${primaryClaim}
• High reliability across ${asset.size_metrics.loc} lines with cleanroom IP warranty
• Drop-in integration into modern distributed service pipelines

Would you be open to reviewing our technical architecture brief?

Best regards,
Commercialization Team`,
            technicalBrief: `Engineered with ${secondCap} and non-blocking asynchronous event handling to maximize concurrent event throughput.`
          }
        },
        {
          id: "buyer-fintech-hft",
          companyName: "Apex Quantitative Trading",
          sector: "Electronic Trading & Financial Systems",
          fitScore: 94.2,
          primaryPainPoint: "Microsecond queuing delays in transaction and state routing layers.",
          matchedCapabilities: [topCap, secondCap],
          annualSavingsEstimateUsd: Math.round(annualEst * 1.2),
          recommendedTier: "Dedicated Node Infrastructure License",
          contactPersona: "Head of Core Systems Architecture",
          suggestedDealSizeUsd: Math.round(annualEst * 0.08),
          pitchAngle: `Eliminate serialization bottlenecks with deterministic memory management.`,
          outreachSequence: {
            emailSubject: `Sub-microsecond message routing module for Apex Quant`,
            emailBody: `Hi [First Name],

In high-throughput financial routing, eliminating synchronization overhead in critical paths is key.

We've built ${asset.name} to deliver ${primaryClaim}.

Can we provide your systems engineering team with a sanitized benchmark test?

Best regards,
Commercialization Team`,
            technicalBrief: `Utilizes pre-allocated buffer pipelines to guarantee predictable execution latencies under high transaction volume.`
          }
        },
        {
          id: "buyer-enterprise-saas",
          companyName: "AetherScale Enterprise Cloud",
          sector: "Enterprise Cloud Platforms & Developer Tooling",
          fitScore: 91.5,
          primaryPainPoint: "High microservice maintenance overhead and backend infrastructure costs.",
          matchedCapabilities: caps.slice(0, 2),
          annualSavingsEstimateUsd: Math.round(annualEst * 0.9),
          recommendedTier: "Dedicated Node Infrastructure License",
          contactPersona: "Chief Architect & Director of Platform Engineering",
          suggestedDealSizeUsd: Math.round(annualEst * 0.06),
          pitchAngle: `Standardize backend pipelines with cleanroom, high-throughput components.`,
          outreachSequence: {
            emailSubject: `Modular backend integration for AetherScale Platform`,
            emailBody: `Hi [First Name],

Reaching out because ${asset.name} provides cleanroom ${langList} infrastructure designed for modular enterprise scale.

Key outcome: ${primaryClaim}.

Happy to send over our technical specification if this aligns with your platform roadmap.

Best regards,
Commercialization Team`,
            technicalBrief: `Modular software package comprising ${asset.size_metrics.file_count} verified files with zero external copyleft dependencies.`
          }
        }
      ];
    }

    // Default OS Substrate / Low-Level / Universal Technical Asset Buyers
    return [
      {
        id: "buyer-hyperscale-cloud",
        companyName: "NexusScale Cloud Systems",
        sector: "Datacenter Hyper-Scaler & Compute Infrastructure",
        fitScore: 98.4,
        primaryPainPoint: "Memory bandwidth saturation and multi-tenant process synchronization bottlenecks.",
        matchedCapabilities: caps.slice(0, 3),
        annualSavingsEstimateUsd: Math.round(annualEst * 1.6),
        recommendedTier: "Enterprise Compute & Value-Share (4.5% of savings)",
        contactPersona: "VP of Cloud Infrastructure & Efficiency",
        suggestedDealSizeUsd: Math.round(annualEst * 0.1),
        pitchAngle: `Integrate ${asset.name} to eliminate process synchronization bottlenecks and compress infrastructure overhead.`,
        outreachSequence: {
          emailSubject: `Optimizing NexusScale compute efficiency with ${asset.name}`,
          emailBody: `Hi [First Name],

I noticed NexusScale has been scaling datacenter infrastructure for high-density compute workloads.

We have engineered a production software asset (${asset.name}) in ${langList} that provides ${topCap}.

Key verified outcome:
• ${primaryClaim}
• Cleanroom DTSA-protected architecture with zero copyleft/GPL contamination
• Extracted across ${asset.size_metrics.loc} lines with formal invariant verification

Would you be open to reviewing a 1-page technical architecture brief and running a 15-minute benchmark in your sandbox?

Best regards,
Commercialization Team`,
          technicalBrief: `Engineered in ${langList} with ${topCap} and ${secondCap} for deterministic execution under high concurrency load.`
        }
      },
      {
        id: "buyer-robotics-fleet",
        companyName: "Vanguard Autonomous Robotics",
        sector: "Autonomous Mobile Robots (AMR) & Industrial Automation",
        fitScore: 94.2,
        primaryPainPoint: "Sensor fusion jitter and scheduler latency causing loop synchronization failures.",
        matchedCapabilities: caps.slice(0, 2),
        annualSavingsEstimateUsd: Math.round(annualEst * 1.1),
        recommendedTier: "OEM Embedded Hardware & Firmware Royalty ($18.50 / activated unit)",
        contactPersona: "Chief Technology Officer & Head of Autonomy",
        suggestedDealSizeUsd: Math.round(annualEst * 0.075),
        pitchAngle: `Guarantee deterministic execution for hardware sensor fusion loops with a drop-in software module.`,
        outreachSequence: {
          emailSubject: `Deterministic runtime for Vanguard Autonomous systems`,
          emailBody: `Hi [First Name],

When scaling autonomous robotics, scheduler jitter frequently introduces sensor synchronization latency spikes.

Our software module (${asset.name}) in ${langList} delivers ${primaryClaim}.

We are offering robotics OEMs an embedded board support license with dedicated integration assistance.

Let me know if you'd like us to share our hardware benchmark logs.

Best regards,
Commercialization Team`,
          technicalBrief: `Integrates ${topCap} to eliminate cache-line thrashing and provide deterministic execution timing.`
        }
      },
      {
        id: "buyer-fintech-hft",
        companyName: "Apex Quantitative Trading",
        sector: "High-Frequency Trading & Electronic Markets",
        fitScore: 91.8,
        primaryPainPoint: "Microsecond packet serialization delays in order routing and state engines.",
        matchedCapabilities: [topCap, secondCap],
        annualSavingsEstimateUsd: Math.round(annualEst * 1.3),
        recommendedTier: "Dedicated Node Infrastructure License",
        contactPersona: "Head of Low-Latency Systems Architecture",
        suggestedDealSizeUsd: Math.round(annualEst * 0.085),
        pitchAngle: `Bypass OS buffer overhead with high-throughput zero-contention queues.`,
        outreachSequence: {
          emailSubject: `Low-latency execution module for Apex Quant (${asset.name})`,
          emailBody: `Hi [First Name],

In low-latency systems, avoiding kernel context switches and serialization lockups is critical.

We've architected ${asset.name} (${langList}) to achieve ${primaryClaim}.

Can we provide your systems engineering team with a sanitized benchmark test?

Best regards,
Commercialization Team`,
          technicalBrief: `Features ${topCap} with cache-line alignment to eliminate bus contention under high concurrent loads.`
        }
      },
      {
        id: "buyer-enterprise-database",
        companyName: "Chronos Distributed Systems",
        sector: "Cloud Native Distributed Systems & Analytics",
        fitScore: 89.5,
        primaryPainPoint: "Ingestion bottlenecks and storage synchronization contention under multi-tenant load.",
        matchedCapabilities: caps.slice(0, 2),
        annualSavingsEstimateUsd: Math.round(annualEst * 0.95),
        recommendedTier: "Dedicated Node Infrastructure License",
        contactPersona: "VP of Engineering & Core Infrastructure Lead",
        suggestedDealSizeUsd: Math.round(annualEst * 0.06),
        pitchAngle: `Accelerate ingestion pipelines with cleanroom, high-throughput components.`,
        outreachSequence: {
          emailSubject: `Accelerating Chronos ingestion throughput with ${asset.name}`,
          emailBody: `Hi [First Name],

Reaching out because our team has engineered ${asset.name}, delivering ${primaryClaim}.

We have packaged this into an enterprise commercial module designed for drop-in pipeline integration.

Happy to send over our engineering whitepaper if this aligns with Chronos's performance roadmap.

Best regards,
Commercialization Team`,
          technicalBrief: `Modular software architecture comprising ${asset.size_metrics.file_count} verified files with automated fault-recovery support.`
        }
      }
    ];
  }
}
