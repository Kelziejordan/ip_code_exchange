/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  FileCode, 
  GitBranch, 
  Zap, 
  CheckCircle2, 
  FolderArchive, 
  Layers, 
  Play, 
  Cpu, 
  ArrowRight,
  Info,
  ShieldCheck,
  FileCheck
} from 'lucide-react';
import { SAMPLE_ASSETS, SampleAssetDefinition } from '../engine/sampleAssets';
import { AssetSourceType } from '../types';

interface AssetIntakeSectionProps {
  onRunAnalysis: (params: {
    inputSource?: string;
    sourceType?: AssetSourceType;
    zipFile?: File;
    customCode?: string;
    assetName?: string;
  }) => Promise<void>;
  isAnalyzing: boolean;
  activeStatus: string;
}

export const AssetIntakeSection: React.FC<AssetIntakeSectionProps> = ({
  onRunAnalysis,
  isAnalyzing,
  activeStatus
}) => {
  const [selectedMode, setSelectedMode] = useState<'upload' | 'code' | 'git' | 'sample'>('upload');
  const [selectedSampleId, setSelectedSampleId] = useState<string>('argos-supervisor-core');
  const [customCode, setCustomCode] = useState<string>(
`// Paste your C, C++, Python, Rust, Go, TypeScript, or CUDA codebase here...
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Enterprise High-Throughput Processing Routine
typedef struct {
    uint64_t sequence_id;
    uint32_t payload_bytes;
    uint32_t status_flags;
} transaction_event_t;

int process_event_stream(transaction_event_t* events, size_t count) {
    if (!events || count == 0) return -1;
    for (size_t i = 0; i < count; i++) {
        events[i].status_flags |= 0x01;
    }
    return 0;
}
`
  );
  const [gitUrl, setGitUrl] = useState<string>('https://github.com/torvalds/linux.git');
  const [uploadedZip, setUploadedZip] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedSample = SAMPLE_ASSETS.find(s => s.id === selectedSampleId) || SAMPLE_ASSETS[0];

  const handleSampleSelect = (sample: SampleAssetDefinition) => {
    setSelectedSampleId(sample.id);
    setCustomCode(sample.files[0].content);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      setUploadedZip(file);
      setSelectedMode('upload');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setUploadedZip(e.target.files[0]);
    }
  };

  const handleStartAnalysis = async () => {
    if (selectedMode === 'upload' && uploadedZip) {
      await onRunAnalysis({
        zipFile: uploadedZip,
        sourceType: 'zip_archive',
        assetName: uploadedZip.name.replace(/\.[^/.]+$/, '')
      });
    } else if (selectedMode === 'code') {
      await onRunAnalysis({
        customCode,
        sourceType: 'raw_code',
        assetName: 'Custom Source Code Asset'
      });
    } else if (selectedMode === 'git') {
      await onRunAnalysis({
        inputSource: gitUrl,
        sourceType: 'repo',
        assetName: gitUrl.split('/').pop()?.replace('.git', '') || 'Git Repository Asset'
      });
    } else if (selectedMode === 'sample') {
      await onRunAnalysis({
        inputSource: selectedSampleId,
        sourceType: selectedSample.sourceType,
        assetName: selectedSample.name
      });
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 md:p-6 shadow-2xl mb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-[#1a1a1a]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Layer 1 // Asset Ingestion Gate
            </span>
            <h2 className="text-sm font-bold text-white font-mono uppercase tracking-tight">
              Technical Asset Upload & AST Analyzer
            </h2>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Submit your codebase, project archive, or source files. The system will unpack, parse AST complexity, and compute valuation and licensing terms based on your code.
          </p>
        </div>

        {/* Bento Mode Selector Tabs */}
        <div className="flex items-center bg-[#050505] p-1 rounded-xl border border-[#1a1a1a] flex-wrap gap-1">
          <button
            id="intake-mode-upload"
            onClick={() => setSelectedMode('upload')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
              selectedMode === 'upload'
                ? 'bg-[#1a1a1a] text-blue-400 border border-[#2a2a2a] shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload Archive (.zip)</span>
          </button>
          <button
            id="intake-mode-code"
            onClick={() => setSelectedMode('code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
              selectedMode === 'code'
                ? 'bg-[#1a1a1a] text-blue-400 border border-[#2a2a2a] shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Paste Source Code</span>
          </button>
          <button
            id="intake-mode-git"
            onClick={() => setSelectedMode('git')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
              selectedMode === 'git'
                ? 'bg-[#1a1a1a] text-blue-400 border border-[#2a2a2a] shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>Git URL</span>
          </button>
          <button
            id="intake-mode-sample"
            onClick={() => setSelectedMode('sample')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
              selectedMode === 'sample'
                ? 'bg-[#1a1a1a] text-blue-400 border border-[#2a2a2a] shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Reference Samples</span>
          </button>
        </div>
      </div>

      {/* Mode 1: Upload Archive (.ZIP) */}
      {selectedMode === 'upload' && (
        <div className="pt-5">
          <input
            ref={fileInputRef}
            type="file"
            accept=".zip,.tar,.gz,.tgz,.c,.cpp,.h,.py,.rs,.go,.ts,.js,.java"
            className="hidden"
            onChange={handleFileChange}
          />
          <div
            id="drag-drop-zone"
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleFileDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition flex flex-col items-center justify-center gap-3 ${
              dragOver
                ? 'border-blue-400 bg-blue-950/20'
                : uploadedZip
                ? 'border-blue-500/50 bg-[#050505]'
                : 'border-[#1a1a1a] hover:border-neutral-700 bg-[#050505]'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <FolderArchive className="w-6 h-6" />
            </div>
            {uploadedZip ? (
              <div>
                <p className="text-sm font-semibold text-blue-400 font-mono">
                  {uploadedZip.name}
                </p>
                <p className="text-xs text-neutral-400 mt-0.5 font-mono">
                  {(uploadedZip.size / 1024).toFixed(1)} KB — Ready to unpack and analyze
                </p>
                <p className="text-[11px] text-neutral-500 mt-1">Click to choose another file or archive</p>
              </div>
            ) : (
              <div>
                <p className="text-sm font-medium text-white font-mono">
                  Drag and drop your codebase <strong className="text-blue-400">(.zip, source files)</strong> here
                </p>
                <p className="text-xs text-neutral-400 mt-1">
                  or click to select from your device. All metrics, AST complexity, valuation, and buyers will be computed directly from your uploaded files.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Mode 2: Paste Code */}
      {selectedMode === 'code' && (
        <div className="pt-5">
          <div className="flex items-center justify-between mb-2 text-xs">
            <label className="text-neutral-400 font-mono font-bold uppercase">Paste Source Code or Specification</label>
            <span className="text-[11px] text-neutral-500 font-mono">{customCode.split('\n').length} lines</span>
          </div>
          <textarea
            id="code-editor-textarea"
            value={customCode}
            onChange={(e) => setCustomCode(e.target.value)}
            rows={10}
            className="w-full bg-[#050505] border border-[#1a1a1a] rounded-xl p-3.5 text-xs font-mono text-blue-300 focus:outline-none focus:border-blue-500 scrollbar-thin"
            placeholder="Paste source code or technical specification here..."
          />
        </div>
      )}

      {/* Mode 3: Git URL */}
      {selectedMode === 'git' && (
        <div className="pt-5">
          <label className="block text-xs font-mono text-neutral-400 mb-2 font-bold uppercase">Remote Git Repository URL</label>
          <div className="flex gap-2">
            <input
              id="git-url-input"
              type="text"
              value={gitUrl}
              onChange={(e) => setGitUrl(e.target.value)}
              className="flex-grow bg-[#050505] border border-[#1a1a1a] rounded-xl px-3 py-2 text-xs font-mono text-blue-300 focus:outline-none focus:border-blue-500"
              placeholder="https://github.com/org/repo.git"
            />
          </div>
          <p className="text-[11px] text-neutral-500 mt-2 font-mono">
            The analyzer will inspect the repository structure, measure cyclomatic complexity, and detect architectural patterns.
          </p>
        </div>
      )}

      {/* Mode 4: Sample Technical Assets (Reference Option) */}
      {selectedMode === 'sample' && (
        <div className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {SAMPLE_ASSETS.map((sample) => {
              const isSelected = selectedSampleId === sample.id;
              return (
                <div
                  key={sample.id}
                  id={`sample-card-${sample.id}`}
                  onClick={() => handleSampleSelect(sample)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#111111] border-blue-500/60 shadow-[0_0_15px_rgba(37,99,235,0.2)]'
                      : 'bg-[#050505] border-[#1a1a1a] hover:border-[#2a2a2a] hover:bg-[#0c0c0c]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-[#111111] text-neutral-300 border border-[#1a1a1a]">
                        {sample.badge}
                      </span>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-blue-400 flex-shrink-0" />
                      )}
                    </div>
                    <h3 className="text-sm font-semibold text-white mb-1 leading-snug font-mono">
                      {sample.name}
                    </h3>
                    <p className="text-[11px] text-neutral-400 line-clamp-3 mb-2 leading-relaxed">
                      {sample.description}
                    </p>
                  </div>
                  <div className="text-[10px] font-mono text-neutral-500 flex items-center justify-between pt-2 border-t border-[#1a1a1a]">
                    <span>{sample.files.length} Source Files</span>
                    <span className="text-blue-400 font-semibold">Test Asset</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-[#050505] p-3 rounded-xl border border-[#1a1a1a] flex items-center justify-between text-xs text-neutral-400">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-400 flex-shrink-0" />
              <span>
                Selected Reference: <strong className="text-white font-mono">{selectedSample.name}</strong> ({selectedSample.files.length} files)
              </span>
            </div>
            <span className="text-[11px] font-mono text-blue-400">Reference File</span>
          </div>
        </div>
      )}

      {/* Action Trigger Banner */}
      <div className="mt-5 pt-4 border-t border-[#1a1a1a] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-neutral-400 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span>
            {isAnalyzing ? (
              <span className="text-blue-400 font-mono animate-pulse">
                STATUS: {activeStatus.toUpperCase()}...
              </span>
            ) : (
              <span className="font-mono">Ready to inspect and extract AST metrics from submitted asset</span>
            )}
          </span>
        </div>

        <button
          id="run-analysis-btn"
          onClick={handleStartAnalysis}
          disabled={isAnalyzing || (selectedMode === 'upload' && !uploadedZip)}
          className="w-full sm:w-auto flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs tracking-wide uppercase transition shadow-[0_0_20px_rgba(37,99,235,0.4)] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          {isAnalyzing ? (
            <>
              <Cpu className="w-4 h-4 animate-spin" />
              <span>Parsing Code & AST...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Analyze & Ingest Technical Asset</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
