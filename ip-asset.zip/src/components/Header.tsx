/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Terminal, 
  DollarSign, 
  FileText, 
  Users, 
  Code2, 
  Sparkles, 
  Layers, 
  Cpu,
  UploadCloud
} from 'lucide-react';

export type TabType = 'bento' | 'intake' | 'valuation' | 'contracts' | 'buyers' | 'apispec';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  onOpenAiAudit: () => void;
  tcsTraceId?: string;
  hasAnalyzed: boolean;
  activeAssetName?: string;
  onLaunchOutreach?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenAiAudit,
  tcsTraceId,
  hasAnalyzed,
  activeAssetName,
  onLaunchOutreach
}) => {
  const tabs = [
    { id: 'intake' as TabType, label: 'Asset Intake & Upload', icon: UploadCloud },
    { id: 'bento' as TabType, label: 'Bento Dashboard', icon: Layers },
    { id: 'valuation' as TabType, label: 'Valuation & Tiers', icon: DollarSign },
    { id: 'contracts' as TabType, label: 'Contracts & Licensing', icon: FileText },
    { id: 'buyers' as TabType, label: 'Buyer Matching', icon: Users },
    { id: 'apispec' as TabType, label: 'API Spec & Sandbox', icon: Code2 }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0a0a0a] border-b border-[#1a1a1a] shadow-2xl">
      {/* Top telemetry & status bar */}
      <div className="px-4 py-2 border-b border-[#1a1a1a]/80 text-[11px] flex flex-wrap items-center justify-between gap-3 text-neutral-400 font-mono">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-blue-400 font-semibold tracking-wide">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            {hasAnalyzed ? 'ROOT_EXEC_MODE // 16-WAY MANIFOLD' : 'ROOT_EXEC_MODE // READY FOR ASSET INTAKE'}
          </div>
          <span className="hidden sm:inline text-neutral-700">|</span>
          <span className="hidden sm:inline text-neutral-400">
            Engine State: <strong className={hasAnalyzed ? "text-blue-400" : "text-neutral-300"}>
              {hasAnalyzed ? "Asset Assessed & Indexed" : "Awaiting User Code Upload"}
            </strong>
          </span>
          <span className="hidden md:inline text-neutral-700">|</span>
          <span className="hidden md:inline text-neutral-400">
            Analysis Mode: <strong className="text-green-500">Zero-Copy AST Inspector</strong>
          </span>
        </div>

        <div className="flex items-center gap-3">
          {tcsTraceId && (
            <span className="bg-[#111111] text-neutral-400 px-2 py-0.5 rounded border border-[#1a1a1a] text-[10px]">
              TCS: <span className="text-blue-400">{tcsTraceId}</span>
            </span>
          )}
          <button
            id="header-ai-audit-btn"
            onClick={onOpenAiAudit}
            disabled={!hasAnalyzed}
            className="flex items-center gap-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 font-semibold px-2.5 py-1 rounded text-xs transition shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            title={hasAnalyzed ? "Run Server-Side Gemini 3.7 Flash IP Audit" : "Analyze an asset first"}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Deep Audit</span>
          </button>
        </div>
      </div>

      {/* Main Bar with Bento branding & active asset */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]">
            A
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold text-white tracking-tight uppercase">
                ArgOS Commercialization Engine
              </h1>
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                v4.2.0-STABLE
              </span>
            </div>
            <p className="text-[10px] text-neutral-500 font-mono">
              Autonomous IP Intake, AST Complexity Profiling & Licensing Manifold
            </p>
          </div>
        </div>

        {/* Right action bar & tab nav */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <div className="hidden lg:flex flex-col items-end mr-1">
            <span className="text-[9px] text-neutral-500 uppercase font-mono tracking-wider">Active Asset</span>
            <span className="text-xs font-mono text-blue-400 truncate max-w-[200px]">
              {activeAssetName || "Awaiting Upload"}
            </span>
          </div>

          <div className="hidden lg:block h-7 w-[1px] bg-[#1a1a1a]"></div>

          <button
            id="launch-outreach-header-btn"
            onClick={onLaunchOutreach}
            disabled={!hasAnalyzed}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-[0_0_15px_rgba(37,99,235,0.3)] transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Users className="w-3.5 h-3.5" />
            <span>LAUNCH OUTREACH</span>
          </button>
        </div>
      </div>

      {/* Bento Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 pb-2">
        <nav className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#1a1a1a] text-white border border-[#2a2a2a] shadow-sm font-semibold'
                    : 'text-neutral-400 hover:text-white hover:bg-[#111111]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-neutral-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
