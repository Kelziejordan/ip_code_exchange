/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building2, 
  Send, 
  Check, 
  Sparkles, 
  Mail, 
  DollarSign, 
  Users, 
  Target, 
  TrendingUp, 
  Copy, 
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { BuyerMatch } from '../types';

interface BuyerDiscoveryAndOutreachViewProps {
  buyerMatches: BuyerMatch[];
  assetName: string;
  onOpenAiAudit: () => void;
}

export const BuyerDiscoveryAndOutreachView: React.FC<BuyerDiscoveryAndOutreachViewProps> = ({
  buyerMatches,
  assetName,
  onOpenAiAudit
}) => {
  const [selectedBuyerId, setSelectedBuyerId] = useState<string>(buyerMatches[0]?.id || '');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [sentMap, setSentMap] = useState<Record<string, boolean>>({});

  const selectedBuyer = buyerMatches.find(b => b.id === selectedBuyerId) || buyerMatches[0];

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSendOutreach = (buyerId: string) => {
    setSentMap(prev => ({ ...prev, [buyerId]: true }));
  };

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 md:p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#1a1a1a]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Layer 4 // Buyer Discovery & Outreach
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                Asset: <strong className="text-neutral-200">{assetName}</strong>
              </span>
            </div>
            <h2 className="text-lg font-bold text-white font-mono uppercase tracking-tight">
              Enterprise Buyer Matching & Deal Flow
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="ai-audit-btn-from-buyers"
              onClick={onOpenAiAudit}
              className="flex items-center gap-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/40 px-3.5 py-2 rounded-xl text-xs font-semibold font-mono transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Deep Buyer Match</span>
            </button>
          </div>
        </div>

        {/* Aggregate Outreach Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 font-mono text-xs">
          <div className="bg-[#050505] p-3.5 rounded-xl border border-[#1a1a1a]">
            <span className="text-[10px] text-neutral-500 uppercase block">Matched Enterprise Buyers</span>
            <span className="text-xl font-bold text-white mt-1 block">{buyerMatches.length} Tier-1 Targets</span>
            <span className="text-[10px] text-blue-400 block mt-0.5">Scored &gt;88% Fit</span>
          </div>

          <div className="bg-[#050505] p-3.5 rounded-xl border border-[#1a1a1a]">
            <span className="text-[10px] text-neutral-500 uppercase block">Total Pipeline Value</span>
            <span className="text-xl font-bold text-blue-400 mt-1 block">
              ${buyerMatches.reduce((acc, b) => acc + b.suggestedDealSizeUsd, 0).toLocaleString()}
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">Annual recurring floor</span>
          </div>

          <div className="bg-[#050505] p-3.5 rounded-xl border border-[#1a1a1a]">
            <span className="text-[10px] text-neutral-500 uppercase block">Max Single Deal Potential</span>
            <span className="text-xl font-bold text-cyan-400 mt-1 block">
              ${Math.max(...buyerMatches.map(b => b.suggestedDealSizeUsd)).toLocaleString()}
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">Hyper-scaler compute</span>
          </div>

          <div className="bg-[#050505] p-3.5 rounded-xl border border-[#1a1a1a]">
            <span className="text-[10px] text-neutral-500 uppercase block">Active Campaign Status</span>
            <span className="text-xl font-bold text-green-500 mt-1 block">
              {Object.keys(sentMap).length} / {buyerMatches.length} Sent
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">Zero Spam Automated Dispatch</span>
          </div>
        </div>
      </div>

      {/* Main Matching Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Matched Buyer List (5 cols) */}
        <div className="lg:col-span-5 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-4 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-2 border-b border-[#1a1a1a]">
              <span className="text-xs font-bold text-neutral-500 uppercase font-mono tracking-wider">
                Qualified Counterparties ({buyerMatches.length})
              </span>
              <span className="text-[10px] text-neutral-500 font-mono">Ranked by Fit Score</span>
            </div>

            <div className="space-y-2.5">
              {buyerMatches.map((buyer) => {
                const isSelected = selectedBuyer?.id === buyer.id;
                const isSent = sentMap[buyer.id];
                return (
                  <div
                    key={buyer.id}
                    id={`buyer-card-${buyer.id}`}
                    onClick={() => setSelectedBuyerId(buyer.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition text-left flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#111111] border-blue-500/60 shadow-[0_0_15px_rgba(37,99,235,0.2)]'
                        : 'bg-[#050505] border-[#1a1a1a] hover:border-neutral-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Building2 className={`w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-blue-400' : 'text-neutral-500'}`} />
                          <h4 className="text-xs font-bold text-white font-mono truncate">{buyer.companyName}</h4>
                        </div>
                        <span className="text-xs font-bold text-blue-400 font-mono flex-shrink-0">
                          {buyer.fitScore.toFixed(1)}% Match
                        </span>
                      </div>

                      <p className="text-[11px] text-neutral-400 mb-2 truncate">{buyer.sector}</p>

                      <div className="flex items-center justify-between text-[10px] font-mono text-neutral-500 pt-2 border-t border-[#1a1a1a]">
                        <span>Est. Deal: <strong className="text-neutral-200">${buyer.suggestedDealSizeUsd.toLocaleString()}</strong></span>
                        {isSent ? (
                          <span className="text-green-400 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Dispatched</span>
                          </span>
                        ) : (
                          <span className="text-blue-400 font-semibold">Ready to send</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1a1a1a] text-[10px] font-mono text-neutral-500 flex items-center justify-between">
            <span>Algorithmic Match Engine v4.2</span>
            <span className="text-blue-400 font-semibold">High-Intent Personas</span>
          </div>
        </div>

        {/* Right: Selected Buyer Persona & Outreach Workspace (7 cols) */}
        <div className="lg:col-span-7 bg-[#0a0a0a] border border-[#1a1a1a] rounded-2xl p-5 shadow-2xl flex flex-col justify-between">
          {selectedBuyer && (
            <div>
              {/* Buyer Overview Banner */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 mb-4 border-b border-[#1a1a1a]">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase">
                      {selectedBuyer.fitScore.toFixed(1)}% Fit Score
                    </span>
                    <span className="text-xs text-neutral-500 font-mono">{selectedBuyer.sector}</span>
                  </div>
                  <h3 className="text-base font-bold text-white font-mono">{selectedBuyer.companyName}</h3>
                </div>

                <div className="text-right">
                  <span className="text-[10px] uppercase font-mono text-neutral-500 block">Target Contact</span>
                  <span className="text-xs font-bold text-blue-400 font-mono block mt-0.5">
                    {selectedBuyer.contactPersona}
                  </span>
                </div>
              </div>

              {/* Pain Point & Value Angle */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 text-xs">
                <div className="bg-[#050505] p-3 rounded-xl border border-[#1a1a1a]">
                  <span className="text-[10px] uppercase font-mono text-neutral-500 block mb-1">Core Pain Point</span>
                  <p className="text-neutral-300 leading-snug">{selectedBuyer.primaryPainPoint}</p>
                </div>

                <div className="bg-[#050505] p-3 rounded-xl border border-[#1a1a1a]">
                  <span className="text-[10px] uppercase font-mono text-neutral-500 block mb-1">Client Economic Gain</span>
                  <p className="text-white font-bold font-mono">
                    ${selectedBuyer.annualSavingsEstimateUsd.toLocaleString()} / year savings
                  </p>
                  <span className="text-[10px] text-neutral-400 block mt-0.5">
                    Target Tier: {selectedBuyer.recommendedTier}
                  </span>
                </div>
              </div>

              {/* Cold Outreach Email Dispatch Box */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1.5 text-xs font-mono">
                  <span className="text-neutral-400 font-bold uppercase flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-blue-400" />
                    <span>Personalized Executive Outreach Template</span>
                  </span>
                  <button
                    id="copy-outreach-email-btn"
                    onClick={() => handleCopy(`${selectedBuyer.outreachSequence.emailSubject}\n\n${selectedBuyer.outreachSequence.emailBody}`, 'email')}
                    className="text-blue-400 hover:text-blue-300 flex items-center gap-1 text-[11px] cursor-pointer"
                  >
                    {copiedField === 'email' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedField === 'email' ? 'Copied' : 'Copy Email'}</span>
                  </button>
                </div>

                <div className="bg-[#050505] p-3.5 rounded-xl border border-[#1a1a1a] text-xs font-mono text-neutral-300 space-y-2">
                  <div className="text-blue-400 pb-1.5 border-b border-[#1a1a1a] font-semibold">
                    Subject: {selectedBuyer.outreachSequence.emailSubject}
                  </div>
                  <div className="whitespace-pre-wrap text-neutral-300 text-[11px] leading-relaxed max-h-48 overflow-y-auto scrollbar-thin">
                    {selectedBuyer.outreachSequence.emailBody}
                  </div>
                </div>
              </div>

              {/* Technical Brief Snippet */}
              <div>
                <span className="text-[10px] uppercase font-mono text-neutral-500 block mb-1">Attached Technical Brief</span>
                <div className="bg-[#050505] p-3 rounded-xl border border-[#1a1a1a] text-[11px] font-mono text-neutral-400">
                  {selectedBuyer.outreachSequence.technicalBrief}
                </div>
              </div>
            </div>
          )}

          {/* Action Trigger */}
          <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex flex-col sm:flex-row items-center justify-between gap-3">
            <span className="text-xs text-neutral-500 font-mono">
              Direct B2B Outreach Pipeline (Layer 4)
            </span>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                id="send-outreach-campaign-btn"
                onClick={() => handleSendOutreach(selectedBuyer.id)}
                className={`w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold font-mono transition cursor-pointer ${
                  sentMap[selectedBuyer.id]
                    ? 'bg-green-600/20 text-green-400 border border-green-500/30'
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]'
                }`}
              >
                {sentMap[selectedBuyer.id] ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Outreach Logged as Sent</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Dispatch Outreach to {selectedBuyer.companyName}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
