/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PrimaryKind = 
  | 'ossubstrate' 
  | 'aimodel' 
  | 'distributed_system' 
  | 'codelibrary' 
  | 'dataset';

export type AssetSourceType = 
  | 'file' 
  | 'repo' 
  | 'model' 
  | 'document' 
  | 'zip_archive' 
  | 'raw_code';

export interface SizeMetrics {
  loc: number;
  file_count: number;
  classes_or_structs: number;
  functions_or_methods: number;
  cyclomatic_index: number;
}

export interface DefensibilityScore {
  category: string;
  score: number; // 0 - 100
  verdict: 'HIGH' | 'MEDIUM' | 'EMERGING';
  description: string;
}

export interface AnalyzedFile {
  path: string;
  loc: number;
  sizeBytes: number;
  kind: string;
  complexityScore: number;
  features: {
    invariants: string[];
    exportedSymbols: string[];
  };
  previewSnippet?: string;
}

export interface AssetObject {
  id: string;
  name: string;
  source_type: AssetSourceType;
  primarykind: PrimaryKind;
  languages: string[];
  files: AnalyzedFile[];
  claims: string[];
  size_metrics: SizeMetrics;
  confidence: number;
  features: {
    capabilities: string[];
    claims: string[];
    architecturePatterns: string[];
    securityFeatures: string[];
  };
  defensibility: DefensibilityScore[];
  created_at: string;
}

export interface ValuationBreakdown {
  valueScore: number; // 1-10
  estimatedAnnualValueUsd: number;
  confidenceInterval: {
    minUsd: number;
    maxUsd: number;
  };
  estimatedTamUsd: number;
  keyDrivers: string[];
}

export interface LicensingTier {
  id: string;
  name: string;
  tagline: string;
  royaltyModel: 'percentage_of_savings' | 'per_node_per_month' | 'per_device_oem' | 'dual_source_royalty';
  rateDescription: string;
  basePriceUsd?: number;
  targetCustomer: string;
  slaLevel: string;
  includedFeatures: string[];
}

export interface ContractClause {
  id: string;
  title: string;
  category: 'Grant' | 'Royalty' | 'Audit' | 'IP Protection' | 'Indemnity' | 'Termination';
  summary: string;
  content: string;
  mandatory: boolean;
}

export interface ContractSpec {
  contractType: string;
  title: string;
  clauses: ContractClause[];
  fullDraftMarkdown: string;
}

export interface BuyerMatch {
  id: string;
  companyName: string;
  sector: string;
  fitScore: number; // 0-100
  primaryPainPoint: string;
  matchedCapabilities: string[];
  annualSavingsEstimateUsd: number;
  recommendedTier: string;
  contactPersona: string;
  suggestedDealSizeUsd: number;
  pitchAngle: string;
  outreachSequence: {
    emailSubject: string;
    emailBody: string;
    technicalBrief: string;
  };
}

export interface LicensingProfile {
  asset: AssetObject;
  valuation: ValuationBreakdown;
  useCases: string[];
  licensingTiers: LicensingTier[];
  contracts: Record<string, ContractSpec>;
  buyerMatches: BuyerMatch[];
  tcsTraceId: string;
}
